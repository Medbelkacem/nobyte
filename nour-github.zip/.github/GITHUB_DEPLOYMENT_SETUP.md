# 🚀 GitHub to Vercel Deployment Setup Guide

Complete checklist and instructions for deploying **NOBTY** from GitHub to Vercel (frontend) + Fly.io (backend).

---

## 📋 Pre-Deployment Checklist

### ✅ Local Project Status

- [ ] All files committed to local Git repo
- [ ] No uncommitted changes (`git status` shows clean)
- [ ] `.env` file excluded from Git (check `.gitignore`)
- [ ] `pocketbase/pb_data/` excluded from Git (database should NOT be committed)
- [ ] No `node_modules/` in Git (pnpm handles this)

### ✅ Build & Tests Pass Locally

```bash
# Install dependencies
pnpm install

# Run type checking
pnpm typecheck

# Run linting
pnpm lint

# Build frontend
pnpm build

# Check PocketBase migrations & hooks syntax
for f in pocketbase/pb_migrations/*.js pocketbase/pb_hooks/*.js scripts/*.mjs; do
  node --check "$f"
done
```

---

## 🐙 GitHub Setup (One-Time)

### 1️⃣ Create GitHub Repository

```bash
# Option A: New repository
git init
git add .
git commit -m "Initial commit: NOBTY PWA"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/nour.git
git push -u origin main

# Option B: Existing repository
git push origin main
```

### 2️⃣ Configure GitHub Secrets

Navigate to **GitHub Repo → Settings → Secrets and variables → Actions**

#### For Backend Deployment (Fly.io)

Create secret: `FLY_API_TOKEN`

```bash
# Generate locally:
fly auth login
fly auth token
# Copy the token and paste into GitHub secret
```

---

## 🌐 Vercel Frontend Deployment

### 1️⃣ Import Project to Vercel

1. Go to **https://vercel.com/new**
2. Click **"Import Git Repository"**
3. Paste: `https://github.com/YOUR_USERNAME/nour.git`
4. Select **GitHub** as source
5. Click **"Import"**

### 2️⃣ Configure Vercel Settings

**Framework Preset:** Vite (auto-detected from `vercel.json`)

**Build & Output:**
- Build Command: `pnpm build`
- Output Directory: `dist`
- Install Command: `pnpm install --no-frozen-lockfile`

**Environment Variables** (add in Vercel dashboard):

```
VITE_PB_URL=https://<YOUR_FLY_APP>.fly.dev
```

Where `<YOUR_FLY_APP>` is your Fly.io app name (e.g., `nobty-prod`).

### 3️⃣ Deploy

- Vercel auto-triggers on every push to `main`
- **Pull Requests** get preview deployments automatically
- **Status checks** appear in GitHub PR comments

---

## 🪰 Fly.io Backend Deployment

### Setup (One-Time)

```bash
# 1. Install Fly CLI
curl -L https://fly.io/install.sh | sh
export PATH=$PATH:/home/$USER/.fly/bin

# 2. Authenticate
fly auth login

# 3. Create app (don't deploy yet)
fly launch \
  --no-deploy \
  --copy-config \
  --name nobty-prod \
  --region cdg

# 4. Create persistent volume for PocketBase data
fly volumes create pb_data \
  --region cdg \
  --size 1
```

### Add Production Secrets

```bash
fly secrets set \
  --app nobty-prod \
  VAPID_PUBLIC_KEY="your_public_key" \
  VAPID_PRIVATE_KEY="your_private_key" \
  VAPID_SUBJECT="mailto:admin@your-domain.com" \
  WEBAUTHN_RP_ID="nobty-prod.fly.dev" \
  WEBAUTHN_ORIGIN="https://your-vercel-domain.vercel.app" \
  WEBAUTHN_RP_NAME="NOBTY"
```

### Generate VAPID Keys

```bash
pnpm push:vapid
# Output example:
# Public Key: BL...
# Private Key: 9...
```

### First Deployment

```bash
# Deploy backend to Fly
fly deploy --app nobty-prod
```

### Automatic Deployments

GitHub Actions workflow (`.github/workflows/deploy-fly.yml`) auto-deploys on:
- Push to `main` touching `Dockerfile`, `fly.toml`, or backend scripts
- Manual trigger via **GitHub Actions**

---

## 📁 Required Files Checklist

### In Root Directory

- ✅ `package.json` — Project metadata & scripts
- ✅ `pnpm-lock.yaml` — Locked dependencies
- ✅ `tsconfig.json` — TypeScript config
- ✅ `vite.config.ts` — Vite bundler config
- ✅ `tailwind.config.ts` — Tailwind CSS config
- ✅ `postcss.config.js` — PostCSS config
- ✅ `eslint.config.js` — ESLint rules
- ✅ `.env.example` — Template for environment variables
- ✅ `.gitignore` — Git exclusion rules
- ✅ `Dockerfile` — Container image for Fly.io
- ✅ `fly.toml` — Fly.io app config
- ✅ `vercel.json` — Vercel build & routing config

### In `.github/` Directory

- ✅ `workflows/ci.yml` — CI pipeline (typecheck, build, lint)
- ✅ `workflows/deploy-fly.yml` — Backend auto-deploy to Fly
- ✅ `DEPLOY.md` — Deployment instructions
- ✅ `GITHUB_DEPLOYMENT_SETUP.md` — This file

### In `src/` Directory

All React/TypeScript source files:
- ✅ `main.tsx` — React entry point
- ✅ `App.tsx` — Main app component
- ✅ `sw.ts` — Service Worker
- ✅ `pages/` — All page components
- ✅ `components/` — All UI components
- ✅ `hooks/` — Custom React hooks
- ✅ `lib/` — Utility functions
- ✅ `providers/` — Context providers
- ✅ `styles/` — Global CSS
- ✅ `types/` — TypeScript types
- ✅ `i18n/` — Localization files

### In `pocketbase/` Directory

- ✅ `pb_migrations/` — Database schema migrations
- ✅ `pb_hooks/` — Backend JavaScript hooks
- ✅ `pb_public/` — Static files served by PocketBase
- ⚠️ `pb_data/` — **DO NOT COMMIT** (local SQLite database)

### In `public/` Directory

- ✅ `icons/` — App icons, PWA manifest icons
- ✅ `patterns/` — SVG patterns (zellij designs)

### In `scripts/` Directory

- ✅ `import-osm.mjs` — OpenStreetMap data import
- ✅ `webauthn-verifier.mjs` — WebAuthn verification server
- ✅ `push-sender.mjs` — Push notification sender
- ✅ `start-prod.sh` — Production startup script

---

## 🔐 Environment Variables

### Development (`.env.local`)

```
VITE_PB_URL=http://127.0.0.1:8090
```

### Production (Vercel Dashboard)

```
VITE_PB_URL=https://nobty-prod.fly.dev
```

### Production (Fly.io Secrets)

```bash
# Set via: fly secrets set --app nobty-prod KEY=VALUE

VAPID_PUBLIC_KEY=...
VAPID_PRIVATE_KEY=...
VAPID_SUBJECT=mailto:admin@your-domain.com
WEBAUTHN_RP_ID=nobty-prod.fly.dev
WEBAUTHN_ORIGIN=https://your-vercel-domain.vercel.app
WEBAUTHN_RP_NAME=NOBTY
```

---

## 🔄 Deployment Workflows

### Automated Frontend (Vercel)

```mermaid
Git Push to main
    ↓
GitHub detects change
    ↓
Vercel webhook triggered
    ↓
Vercel runs: pnpm install && pnpm build
    ↓
Output dist/ → Vercel CDN
    ↓
✅ Live on https://your-vercel-domain.vercel.app
```

### Automated Backend (Fly.io + GitHub Actions)

```mermaid
Git Push to main (backend files changed)
    ↓
GitHub Actions ci.yml runs
    ↓
Syntax & build checks pass
    ↓
GitHub Actions deploy-fly.yml triggered
    ↓
flyctl deploy --remote-only
    ↓
✅ Backend live on https://nobty-prod.fly.dev
```

### Manual Deployments

#### Frontend (via Vercel UI)
- **Redeploy:** https://vercel.com/dashboard → Project → Deployments → Redeploy

#### Backend (via GitHub UI)
- **Actions** → *Deploy backend → Fly.io* → *Run workflow*
- Or manually: `flyctl deploy --app nobty-prod`

---

## 🧪 Testing Deployment

### After Vercel Deploy

```bash
# Check frontend is live
curl https://your-vercel-domain.vercel.app

# Check Service Worker installed
curl -I https://your-vercel-domain.vercel.app/sw.js

# Verify env var is set
# (Open DevTools → Network → check XHR to your Fly.io backend)
```

### After Fly.io Deploy

```bash
# Check backend is responding
curl https://nobty-prod.fly.dev/api/collections

# Check PocketBase Admin UI
# (Open https://nobty-prod.fly.dev/_/ in browser)

# View logs
fly logs -a nobty-prod --follow
```

---

## 🛠️ Troubleshooting

### ❌ Vercel Build Fails

**Check CI workflow first:**
```bash
pnpm install
pnpm typecheck
pnpm build
```

**Then check Vercel logs:** https://vercel.com/dashboard → Project → Deployments → Failed deployment

**Common issues:**
- Missing `VITE_PB_URL` env var → add to Vercel dashboard
- TypeScript errors → `pnpm typecheck` locally
- Import path issues → verify `tsconfig.json` paths

### ❌ Fly.io Deploy Fails

**Check logs:**
```bash
fly logs -a nobty-prod --follow
```

**Common issues:**
- Volume not attached → `fly volumes list -a nobty-prod`
- Missing secrets → `fly secrets list -a nobty-prod`
- Dockerfile issues → test locally: `docker build -t nobty .`

### ❌ GitHub Actions Fails

**Check workflow run:** GitHub → Actions → Select workflow → Click run

**Common issues:**
- Missing `FLY_API_TOKEN` secret → add to GitHub Settings → Secrets
- Node version mismatch → update `node-version` in workflow
- PNPM version → verify in workflow matches local: `pnpm --version`

---

## 📚 Reference Docs

- **Vercel:** https://vercel.com/docs
- **Fly.io:** https://fly.io/docs/
- **GitHub Actions:** https://docs.github.com/en/actions
- **Vite:** https://vitejs.dev/
- **PocketBase:** https://pocketbase.io/docs/
- **React Router:** https://reactrouter.com/

---

## ✨ Summary

**To deploy NOBTY to GitHub + Vercel:**

1. ✅ All errors fixed (run `pnpm typecheck && pnpm build`)
2. ✅ Push to GitHub: `git push origin main`
3. ✅ Connect Vercel: https://vercel.com/new
4. ✅ Set `VITE_PB_URL` env in Vercel
5. ✅ Fly backend auto-deploys via GitHub Actions
6. ✅ Monitor: Vercel dashboard + `fly logs -a nobty-prod`

**Subsequent deployments:** Just push to `main`, both frontends & backend auto-deploy! 🎉
