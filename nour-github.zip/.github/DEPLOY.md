# Déploiement depuis GitHub

Ce document complète la section *Déploiement production* du `README.md`
en se concentrant sur le flux **push GitHub → déploiement automatique**.

## Frontend → Vercel (Git Integration)

1. Poussez le repo sur GitHub.
2. https://vercel.com/new → *Import Git Repository* → sélectionnez ce repo.
3. Framework Preset : **Vite** (auto-détecté grâce à `vercel.json`).
4. Settings → Environment Variables :
   - `VITE_PB_URL` = `https://<votre-app>.fly.dev`
5. Deploy. Vercel rebuildra à chaque push sur `main` ;
   les PRs reçoivent un *Preview Deployment*.

Aucun workflow GitHub Action nécessaire — Vercel pull/build/deploy lui-même.

## Backend → Fly.io (GitHub Action)

Le workflow `.github/workflows/deploy-fly.yml` déclenche `flyctl deploy`
à chaque push sur `main` qui touche le backend (Dockerfile, `fly.toml`,
`pb_hooks/`, `pb_migrations/`, scripts sidecars).

### Préparation (une fois)

```bash
# 1. Installez flyctl localement et créez l'app + le volume :
fly auth login
fly launch --no-deploy --copy-config --name <votre-app>
fly volumes create pb_data --region cdg --size 1

# 2. Définissez les secrets de production :
fly secrets set \
  VAPID_PUBLIC_KEY="BL..." \
  VAPID_PRIVATE_KEY="9..." \
  VAPID_SUBJECT="mailto:contact@votre-domaine" \
  WEBAUTHN_RP_ID="<votre-app>.fly.dev" \
  WEBAUTHN_ORIGIN="https://<frontend>.vercel.app" \
  WEBAUTHN_RP_NAME="NOBTY"
  # + optionnel : ANTHROPIC_API_KEY, TWILIO_*, VONAGE_*, OPENAI_API_KEY

# 3. Récupérez un token et stockez-le dans GitHub :
fly auth token
#   → GitHub repo → Settings → Secrets and variables → Actions
#     → New repository secret : FLY_API_TOKEN = <token>
```

### Trigger manuel

GitHub repo → **Actions** → *Deploy backend → Fly.io* → *Run workflow*.

## CI

`.github/workflows/ci.yml` est lancé sur chaque PR + push `main` :
- typecheck (`pnpm typecheck`)
- build (`pnpm build`) — détecte les erreurs avant Vercel
- syntax-check de toutes les migrations + hooks PocketBase

L'artifact `dist/` est archivé 7 jours pour comparaison visuelle si besoin.
